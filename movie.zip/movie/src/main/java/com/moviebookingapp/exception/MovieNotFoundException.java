package com.moviebookingapp.exception;

public class MovieNotFoundException extends MovieBookingException {

    public MovieNotFoundException(String message) {
        super(message);
    }
}
