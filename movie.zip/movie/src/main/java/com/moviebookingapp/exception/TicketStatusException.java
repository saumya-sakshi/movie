package com.moviebookingapp.exception;

public class TicketStatusException extends MovieBookingException {

    public TicketStatusException(String message) {
        super(message);
    }

}
