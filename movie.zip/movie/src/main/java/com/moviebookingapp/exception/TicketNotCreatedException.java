package com.moviebookingapp.exception;

public class TicketNotCreatedException extends MovieBookingException {

    public TicketNotCreatedException (String message) {
        super(message);
    }

}
