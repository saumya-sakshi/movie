package com.moviebookingapp.exception;

public class TicketException extends MovieBookingException {

    public TicketException(String message) {
        super(message);
    }
    
}
