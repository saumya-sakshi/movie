package com.moviebookingapp.exception;

public class TicketAndSeatMisMatch extends MovieBookingException {

    public TicketAndSeatMisMatch(String message) {
        super(message);
    }
	

}
