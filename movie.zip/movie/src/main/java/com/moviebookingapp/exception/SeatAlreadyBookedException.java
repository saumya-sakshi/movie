package com.moviebookingapp.exception;

public class SeatAlreadyBookedException extends MovieBookingException {

    public SeatAlreadyBookedException(String message) {
        super(message);
    }

}
